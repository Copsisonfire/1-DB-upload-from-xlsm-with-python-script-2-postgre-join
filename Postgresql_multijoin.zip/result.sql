CREATE VIEW result AS
SELECT p.endpoint_id,
       p.mode_start,
       (p.mode_start + p.mode_duration) AS mode_end,
	   p.mode_duration,
	   p.lable,
	   r.reason,
	   o.operator_name,
       SUM(e.kwh) AS sum_kwh
FROM periods p
LEFT JOIN energy e ON e.endpoint_id = p.endpoint_id 
			 AND e.event_time BETWEEN p.mode_start AND (p.mode_start + p.mode_duration)
LEFT JOIN reasons r ON r.endpoint_id = p.endpoint_id 
			 AND r.event_time BETWEEN p.mode_start AND (p.mode_start + p.mode_duration)
LEFT JOIN operators o ON o.endpoint_id = p.endpoint_id 
			 AND o.login_time <= p.mode_start
			 AND o.logout_time >= (p.mode_start + p.mode_duration)
GROUP BY p.endpoint_id, p.mode_start, (p.mode_start + p.mode_duration), p.mode_duration, 
			 p.lable, r.reason, o.operator_name
ORDER BY p.endpoint_id, p.mode_start